<?php
// Check for empty fields
if(empty($_POST['nama']) || empty($_POST['email']) || empty($_POST['telepon']) || empty($_POST['pesan']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
  http_response_code(500);
  exit();
}

$nama = strip_tags(htmlspecialchars($_POST['nama']));
$email = strip_tags(htmlspecialchars($_POST['email']));
$telepon = strip_tags(htmlspecialchars($_POST['telepon']));
$pesan = strip_tags(htmlspecialchars($_POST['pesan']));

// Create the email and send the message
$to = "akbar.bafunazair78@gmail.com"; // Add your email address in between the "" replacing yourname@yourdomain.com - This is where the form will send a message to.
$subject = "Website Contact Form:  $nama";
$body = "You have received a new pesan from your website contact form.\n\n"."Here are the details:\n\nName: $nama\n\nEmail: $email\n\nPhone: $telepon\n\nMessage:\n$pesan";
$header = "From: noreply@yourdomain.com\n"; // This is the email address the generated message will be from. We recommend using something like noreply@yourdomain.com.
$header .= "Reply-To: $email";	
if(!mail($to, $subject, $body, $header))
  http_response_code(500);
?>
