<?php
//Include file koneksi ke database
include "koneksi.php";

//menerima nilai dari kiriman form pendaftaran
$nama=$_POST["nama"];
$email=$_POST["email"];
$telepon=$_POST['telepon'];
$pesan=$_POST['pesan'];


//Query input menginput data kedalam tabel anggota
  $sql="INSERT INTO contact (nama,email,telepon,pesan) VALUES
		('$nama','$email','$telepon','$pesan')";

//Mengeksekusi/menjalankan query diatas	
  $hasil=mysqli_query($conn,$sql);

//Kondisi apakah berhasil atau tidak
  if ($hasil) {
	echo "Berhasil Mengirim Data Klik <a href='contact.php'>Kembali</a> ";
	exit;
  }
else {
	echo "Gagal Mengirim Data Klik <a href='contact.php'>Kembali</a>";
	exit;
}  

?>