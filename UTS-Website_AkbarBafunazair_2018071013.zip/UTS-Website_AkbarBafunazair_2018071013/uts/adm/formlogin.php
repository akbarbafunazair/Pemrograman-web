<!DOCTYPE html>
<html>
<head>
	<title>FORM LOGIN ADMIN PORTOFOLIO</title>
	<link rel="stylesheet" type="text/css" href="../css/style1.css">
</head>
<body>
	<br/>
	<br/>
	<center><h2>FORM LOGIN ADMIN PORTOFOLIO</h2></center>
	<center><h2>HANYA ADMIN WEBSITE YANG BISA MASUK<h2></center>	
	<br/>
	<div class="login">
	<br/>
		<form action="login.php" method="post">
			<div>
				<label>Username:</label>
				<input type="text" name="username"/>
			</div>
			<div>
				<label>Password:</label>
				<input type="password" name="password"/>
			</div>			
			<div>
				<input type="submit"  value="LOGIN" class="tombol">
				<br>
				<h10><a href="../index.php">Kembali Halaman Utama</a></h10>
			</div>
		</form>
	</div>
</body>
<script type="text/javascript">
</script>
</html>