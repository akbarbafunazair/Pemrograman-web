<?php

    include('../koneksi.php');

    if($_GET['id']){

        $id = $_GET['id'];
        $query = "SELECT * FROM `about` WHERE id='$id'";

        $result = mysqli_query($conn,$query);

        if(mysqli_num_rows($result) > 0){

            while($row=mysqli_fetch_assoc($result)){
                $about = $row['about'];
            }
        }else{
            header('Location: about.php');
        }
    }

    if(isset($_POST['submit']))
    {
        if(isset($_POST['editor']) && !empty($_POST['editor']))
        {
            $about = $_POST['editor'];
        }else{
            $empty_erorr = '<b class="text-danger tex-center>
                    Please fill the textarea</b>';
        }
        if(isset($about) && !empty($about))
        {
            $insert_q = "UPDATE `about` SET about = '$about' WHERE id='$id'";

            if(mysqli_query($conn,$insert_q)){

            }else{
                $submit_error = '<b class="text-danger tex-center>
                    You re not able to submit. please try again.</b>';
                }
            }
        }

?>
<!DOCTYPE html>
<html>
<head>
    <title>CK EDITOR</title>

</head>
    <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Freelancer - Start Bootstrap Theme</title>
        <script src="../ckeditor/ckeditor.js"></script>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.13.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="../css/styles.css" rel="stylesheet" />
        <link href="css/sample.css" rel="stylesheet">
<body id="page-top">
    <!-- Navigation-->
        <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="#page-top">HALAMAN INPUT ABOUT</a>
                <button class="navbar-toggler navbar-toggler-right text-uppercase font-weight-bold bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                         <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href=""></a></li>
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href=""></a></li>
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href=""></a></li>
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href=""></a></li>
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href=""></a></li>
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="about1.php">BACK</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <br>
        <?php if (isset($submit_error)) echo $submit_error; ?>
        <?php if (isset($empty_erorr)) echo $empty_erorr; ?> 

        <form action="" method="post" enctype="multipart/form-data">
        <textarea class="ckeditor" name="editor"><?php if (isset($about)) echo $about ?></textarea>
        <br>
        <button type="submit" name="submit" class="btn btn-succes">
        <span class="fa fa-save"></span></button>
        </div>    
</body>
</form>
