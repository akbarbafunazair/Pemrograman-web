<?php

include '../koneksi.php';
$username = $_POST['username'];
$password = $_POST['password'];


if (!empty($username)&& !empty($password)) {
	$sql = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username' AND password='$password'");
	$result = mysqli_num_rows($sql);

	if ($result){
		echo "Anda Berhasil Masuk ";
		echo "Klik <a href='admin.php'>disini</a> untuk melanjutkan";
	} else {
		echo "Username Dan Password Salah, Klik <a href='formlogin.php'>Kembali</a>";
	}
} else {
	echo "Email Dan Password Anda Kosong, Silahkan Diisi.";
}
?>